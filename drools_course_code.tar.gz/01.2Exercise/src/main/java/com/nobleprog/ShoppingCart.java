package com.nobleprog;

public class ShoppingCart {

	private double totalPrice;
	private double discount;
	
	public ShoppingCart(double tp) {
		this.setTotalPrice(tp);
		this.setDiscount(0.0);
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

}
