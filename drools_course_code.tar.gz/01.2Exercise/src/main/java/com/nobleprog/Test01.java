package com.nobleprog;

import static org.junit.Assert.*;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;



public class Test01 {
	@Test
	public void test1(){
        // load up the knowledge base
        KieServices ks = KieServices.Factory.get();
	    KieContainer kContainer = ks.getKieClasspathContainer();
    	StatelessKieSession kSession = kContainer.newStatelessKieSession("ksession-stateless");
		
		/**
		 * For all ShoppingCarts with 'totalPrices' greater than 10000, apply 10% discount in the field 'discount'
		 * Write two tests, one for shopping cart with a discount and one without
		 */
    	ShoppingCart sc = new ShoppingCart(12000.00);
    	assertFalse(sc.getDiscount() == 0.1);
    	kSession.execute(sc);
    	assertTrue(sc.getDiscount() == 0.1);
    	
	}
}


