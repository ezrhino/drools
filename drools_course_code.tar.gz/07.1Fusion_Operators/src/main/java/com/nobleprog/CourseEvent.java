package com.nobleprog;

import java.util.Date;


	
public class CourseEvent {
	
		CourseEvent(String name,Date startDate,long d){
			this.name = name;
			this.startDate = startDate;
			this.duration = d;
			this.booked = false;
		
		}
		
		String name;
		Double price;
		boolean booked;
		Date startDate;
		long duration;
		
		public String getName() {
			return name;
		}
		public Date getStartDate() {
			return startDate;
		}
		public void setStartDate(Date startDate) {
			this.startDate = startDate;
		}
		public long getDuration() {
			return duration;
		}
		public void setDuration(long duration) {
			this.duration = duration;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Double getPrice() {
			return price;
		}
		public void setPrice(Double price) {
			this.price = price;
		}
		public boolean isBooked() {
			return booked;
		}
		public void setBooked(boolean booked) {
			this.booked = booked;
		}
	
}

