package com.nobleprog;

import java.util.Calendar;
import java.util.Date;
import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.EntryPoint;


public class Test02_EntryPoints {
	@Test
	public void test1(){

		KieServices ks = KieServices.Factory.get();
		KieContainer kContainer = ks.getKieClasspathContainer();
		KieSession ksession = kContainer.newKieSession("ksession-rules");


		CourseEvent e1 = new CourseEvent( "Drulz for Developers",createDate(2012,1,1),(long) (0));
		CourseEvent e2 = new CourseEvent( "Drools for Managers",createDate(2012,1,2),(long) (0));

		EntryPoint plStream = ksession.getEntryPoint( "PL" );
		plStream.insert( e1 );

		EntryPoint ukStream = ksession.getEntryPoint( "UK" );
		ukStream.insert( e2 );


		
		ksession.fireAllRules();
	}
     
	
	   private static Date createDate(int year, int month, int day, int hour ,int min, int sec) {
	        Calendar calendar = Calendar.getInstance();
	        calendar.set(Calendar.YEAR, year);
	        calendar.set(Calendar.MONTH, month-1);
	        calendar.set(Calendar.DATE, day);
	        calendar.set(Calendar.HOUR, hour);
	        calendar.set(Calendar.MINUTE, min);
	        calendar.set(Calendar.SECOND, sec);

	        return new Date(calendar.getTimeInMillis());
	    }
	   
	   private static Date createDate(int year, int month, int day) {
		   return createDate(year,month,day,0,0,0);
	   }
}


