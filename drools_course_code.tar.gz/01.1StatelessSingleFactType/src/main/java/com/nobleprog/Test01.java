package com.nobleprog;

import static org.junit.Assert.*;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;



public class Test01 {
	@Test
	public void test1(){
        // load up the knowledge base
        KieServices ks = KieServices.Factory.get();
	    KieContainer kContainer = ks.getKieClasspathContainer();
    	StatelessKieSession kSession = kContainer.newStatelessKieSession("ksession-stateless");
		
		
		Applicant applicant = new Applicant( "Mr John Smith", 16 );

		assertTrue( applicant.isValid() );

		kSession.execute( applicant );

		assertFalse( applicant.isValid() );

	}
}


