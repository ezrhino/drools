package com.nobleprog;

public class FactModel{

	public static class Emp {
		
		public Emp(long id, String name, String job, long mgr, int hiredate,
				long sal, int deptno) {
			super();
			this.id = id;
			this.name = name;
			this.job = job;
			this.mgr = mgr;
			this.hiredate = hiredate;
			this.sal = sal;
			this.deptno = deptno;
		}
		private long id;
		private String name;
		private String job;
		private long mgr;
		private int hiredate;
		private long sal;
		private int deptno;
		
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getJob() {
			return job;
		}
		public void setJob(String job) {
			this.job = job;
		}
		public long getMgr() {
			return mgr;
		}
		public void setMgr(long mgr) {
			this.mgr = mgr;
		}
		public int getHiredate() {
			return hiredate;
		}
		public void setHiredate(int hiredate) {
			this.hiredate = hiredate;
		}
		public long getSal() {
			return sal;
		}
		public void setSal(long sal) {
			this.sal = sal;
		}
		public int getDeptno() {
			return deptno;
		}
		public void setDeptno(int deptno) {
			this.deptno = deptno;
		}
	
		public String toString() {
			return id + " " + name + " " + deptno;
		}
	}	
}