package com.nobleprog;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;


public class Test01 {
	@Test
	public void test1(){
		
        KieServices ks = KieServices.Factory.get();
	    KieContainer kContainer = ks.getKieClasspathContainer();
    	StatelessKieSession kSession = kContainer.newStatelessKieSession("ksession-stateless");
    	/**
    	 *  Extend model from exercise 1.2:
    	 *  - add Customer fact type with returningCustomer:Boolean attribute
    	 *  - add 'customer:Customer' field to ShoppingCart fact type
    	 *  - create a rule which would apply 20% discount (using the same discount field) if the customer is returningCustomer
    	 *  Write test covering shopping carts below:
    	 *  Customer: new, totalPrice 3000
    	 *  Customer: returning, totalPrice 50000
    	 *  
    	 *  
    	 *  What about the order of the rules? Which discount is applied first?
    	 *  Advanced:
    	 *  1. Apply solution 1
    	 *  	- use silence (in production not recommended)
    	 *  2. Apply solution 2
    	 *   - returningCustomerDiscount:BigDecimal and priceTotalWithDiscounts:BigDecimal fields, 
    	 *   - create a rule which will apply only bigger discount
    	 *  
    	 */
	}

}
