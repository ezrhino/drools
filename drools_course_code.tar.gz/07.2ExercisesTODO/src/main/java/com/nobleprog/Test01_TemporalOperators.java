package com.nobleprog;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;
import org.kie.api.runtime.rule.EntryPoint;

public class Test01_TemporalOperators {
	@Test
	public void test1(){
        KieServices ks = KieServices.Factory.get();
	    KieContainer kContainer = ks.getKieClasspathContainer();
    	StatelessKieSession ksession = kContainer.newStatelessKieSession("ksession-stateless");
		
		CourseEvent e1 = new CourseEvent( "Drools for Managers",createDate(2012,1,2),(long) (1));
		CourseEvent e2 = new CourseEvent( "Drools for Beginners",createDate(2012,1,1),(long) (0));
		
		ksession.execute( Arrays.asList( new Object[] { e1, e2 } ) );
	}
     
	   private static Date createDate(int year, int month, int day, int hour ,int min, int sec) {
	        Calendar calendar = Calendar.getInstance();
	        calendar.set(Calendar.YEAR, year);
	        calendar.set(Calendar.MONTH, month-1);
	        calendar.set(Calendar.DATE, day);
	        calendar.set(Calendar.HOUR, hour);
	        calendar.set(Calendar.MINUTE, min);
	        calendar.set(Calendar.SECOND, sec);

	        return new Date(calendar.getTimeInMillis());
	    }
	   

	   private static Date createDate(int year, int month, int day) {
		   return createDate(year,month,day,0,0,0);
	   }
}