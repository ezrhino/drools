package com.nobleprog;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import com.nobleprog.FactModel.*;


public class Test01simple {
	@Test
	public void test1(){
		
		//matching Object()
		//Match inheritated facts
		
	}
}

	
	
	
	