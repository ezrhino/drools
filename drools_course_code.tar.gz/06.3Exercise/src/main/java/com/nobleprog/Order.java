	package com.nobleprog;
	
	public class Order {
		Order(String name,int total){
			this.name = name;
		}
		
	    private String name;
	    
	    
	    public Order(String name, boolean earlyBooking,
				boolean existingCustomer, double total) {
			super();
			this.name = name;
			this.earlyBooking = earlyBooking;
			this.existingCustomer = existingCustomer;
			this.total = total;
		}

		private boolean earlyBooking;
	    private boolean existingCustomer;
	    
	    
	    public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public boolean isEarlyBooking() {
			return earlyBooking;
		}
		public void setEarlyBooking(boolean earlyBooking) {
			this.earlyBooking = earlyBooking;
		}
		public boolean isExistingCustomer() {
			return existingCustomer;
		}
		public void setExistingCustomer(boolean existingCustomer) {
			this.existingCustomer = existingCustomer;
		}
		public double getTotal() {
			return total;
		}
		public void setTotal(double total) {
			this.total = total;
		}
		public String toString() {
			return "name=" + name + "\n\tearlyBooking=" + earlyBooking +
			       "\n\texistingCustomer=" + existingCustomer +
			       "\n\ttotal=" + total;
		}
		private double total;
	    
	}

