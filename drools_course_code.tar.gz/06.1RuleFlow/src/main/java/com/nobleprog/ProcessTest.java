package com.nobleprog;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

/**
 * This is a sample file to launch a process.
 */
public class ProcessTest {

    
	@Test
	public void Test01() {
        
		KieServices ks = KieServices.Factory.get();
		KieContainer kContainer = ks.getKieClasspathContainer();
		KieSession ksession = kContainer.newKieSession("ksession-rules");
            
       ksession.startProcess("_40_Ruleflow.ruleflow");
       ksession.fireAllRules();
        
    }


}
