package com.nobleprog;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import com.nobleprog.FactModel.*;


public class Test03regular_expressions {
	@Test
	public void test1(){
		KieServices ks = KieServices.Factory.get();
		KieContainer kContainer = ks.getKieClasspathContainer();
		KieSession ksession = kContainer.newKieSession("ksession-rules2");
		/** 
		 * Prepare Data
		 */
		ksession.insert( new Salgrade(1,700,1200));
		ksession.insert( new Salgrade(2,1201,1400));
		ksession.insert( new Salgrade(3,1401,2000));
		ksession.insert( new Salgrade(4,2001,3000));
		ksession.insert( new Salgrade(5,3001,9999));
		 
		ksession.insert( new Dept(10,"ACCOUNTING","NEW YORK"));
		ksession.insert( new Dept(20,"RESEARCH","LONDON"));
		ksession.insert( new Dept(30,"SALES","PARIS"));
		ksession.insert( new Dept(40,"OPERATIONS","BERLIN"));	
		
		
		ksession.insert( new Emp(7839,"BUSH"	,"PRESIDENT",0   ,1981,5000,10) );
		ksession.insert( new Emp(7698,"BLAIR"	,"MANAGER"	,7839,1981,2850,30));
		ksession.insert( new Emp(7782,"MERKEL"	,"MANAGER"	,7839,1981,2450,10));
		ksession.insert( new Emp(7566,"PUTIN"	,"MANAGER"	,7839,1981,2975,20));
		ksession.insert( new Emp(7654,"CHIRACK"	,"SALESMAN"	,7698,1981,1250,30));
		ksession.insert( new Emp(7499,"BAROSSO"	,"SALESMAN"	,7698,1981,1600,30));
		ksession.insert( new Emp(7844,"GATES"	,"SALESMAN"	,7698,1981,1500,30));
		ksession.insert( new Emp(7900,"BUFFETT"	,"CLERK"	,7698,1981,950 ,30));
		ksession.insert( new Emp(7521,"WALTON"	,"SALESMAN"	,7698,1981,1250,30));
		ksession.insert( new Emp(7902,"TOOSK"	,"ANALYST"	,7566,1981,3000,20));
		ksession.insert( new Emp(7369,"THATCHER","CLERK"	,7902,1980,800 ,20));
		ksession.insert( new Emp(7788,"CARNEGIE","ANALYST"	,7566,1982,3000,20));
		ksession.insert( new Emp(7876,"FORD"	,"CLERK"	,7788,1983,1100,20));
		ksession.insert( new Emp(7934,"ELISON"	,"CLERK"	,7782,1982,1300,10));
		
		ksession.fireAllRules();
	}
}

	
	
	
	