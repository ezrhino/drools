package com.nobleprog;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EndDate  {
	private Date date;

	public EndDate(Date date) {
		this.date = date;
	}

	public EndDate(String date) throws ParseException {
	   SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");      		

		this.date = dateFormat.parse(date);
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String toString(){
		   SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");      		
		return dateFormat.format(this.date)  ;
	}		
}