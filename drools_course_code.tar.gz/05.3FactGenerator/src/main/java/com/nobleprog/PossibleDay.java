package com.nobleprog;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PossibleDay  {
	private Date date;

	public PossibleDay(Date date) {
		this.date = date;
	}
	public PossibleDay(String date) throws ParseException {
	   SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");      		

		this.date = dateFormat.parse(date);
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	public String toString(){
		   SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");      		
		return dateFormat.format(this.date)  ;
	}
	
	public PossibleDay nextDay(){
		long nextDayLong = this.date.getTime() + (1000 * 60 * 60 * 24);
		return new PossibleDay(new Date(nextDayLong));
			
	}
	
}
