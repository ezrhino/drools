package com.nobleprog;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;

 
public class Test01 {
	@Test
	public void test1(){
		
        KieServices ks = KieServices.Factory.get();
	    KieContainer kContainer = ks.getKieClasspathContainer();
    	StatelessKieSession kSession = kContainer.newStatelessKieSession("ksession-stateless");
		

		Applicant applicant = new Applicant( "Bob", 20 );

		Application application = new Application();
		application.setApplicant(applicant);

		//Was the application filed before deadline?
		application.setOnTime(false);

		assertTrue( application.isValid() );

		kSession.execute( Arrays.asList( new Object[] { application, applicant } ) );

		assertFalse( application.isValid() );	}
}
