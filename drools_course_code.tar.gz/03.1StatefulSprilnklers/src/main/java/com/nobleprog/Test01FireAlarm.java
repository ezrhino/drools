package com.nobleprog;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.nobleprog.FactModel.Fire;
import com.nobleprog.FactModel.Room;
import com.nobleprog.FactModel.Sprinkler;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.StatelessKieSession;
import org.kie.api.runtime.rule.FactHandle;

public class Test01FireAlarm {
	@Test
	public void test1(){
	
		   KieServices ks = KieServices.Factory.get();
		    KieContainer kContainer = ks.getKieClasspathContainer();
	    	KieSession ksession = kContainer.newKieSession("ksession-rules");
			
	
		/** 
		 * Prepare Data
		 */
		String[] names = new String[]{"kitchen", "bedroom", "office", "livingroom"};

		Map<String,Room> name2room = new HashMap<String,Room>();

		for( String name: names ){

		    Room room = new Room( name );

		    name2room.put( name, room );

		    ksession.insert( room );

		    Sprinkler sprinkler = new Sprinkler( room );

		    ksession.insert( sprinkler );

		}


		ksession.fireAllRules();
		
		
		
		/** 
		 * Put the kitchen and office of fire
		 */
		  Fire kitchenFire = new Fire( name2room.get( "kitchen" ) );

		  Fire officeFire = new Fire( name2room.get( "office" ) );


		  FactHandle kitchenFireHandle = ksession.insert( kitchenFire );

		  FactHandle officeFireHandle = ksession.insert( officeFire );


		  ksession.fireAllRules();
	
		  /** 
		   * Fire is gone, write a rule which will turn the sprinklers off
		   */
		  ksession.delete( kitchenFireHandle );

		  ksession.delete( officeFireHandle );


		  ksession.fireAllRules();
	}
		
}

	
	
	
	