package com.nobleprog;

public class  FactModel{
	public static class Room {
	
		Room(String name){
			this.name = name;
		}
	    private String name;
 
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
	
	
	}
	
	public static class Sprinkler {
		private boolean on;
	    
		private Room room;

	    
	    
		Sprinkler(Room room){
			this.room = room;
		}
	
	    public Room getRoom() {
			return room;
		}

		public void setRoom(Room room) {
			this.room = room;
		}

		public boolean isOn() {
			return on;
		}

		public void setOn(boolean on) {
			this.on = on;
		}

		
	}
	
	public static class Fire {
	
		Fire(Room room){
			this.room = room;
		}
		private Room room;
		
		

		public Room getRoom() {
			return room;
		}

		public void setRoom(Room room) {
			this.room = room;
		}

	
	
	}
	
	public static class Alarm {
	
	}
}