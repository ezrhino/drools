package com.nobleprog;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;
import org.kie.internal.event.KnowledgeRuntimeEventManager;
import org.kie.internal.logger.KnowledgeRuntimeLogger;
import org.kie.internal.logger.KnowledgeRuntimeLoggerFactory;

import com.nobleprog.FactModel.*;

public class Test01 {
	@Test
	public void test1() {
		KieServices ks = KieServices.Factory.get();
		KieContainer kContainer = ks.getKieClasspathContainer();
		KieSession ksession = kContainer.newKieSession("ksession-rules");

		/**
		 * Prepare Data
		 */
		ksession.insert(new Emp(7839, "BUSH", "PRESIDENT", 0, 1981, 5000, 10));
		ksession.insert(new Emp(7782, "MERKEL", "MANAGER", 7839, 1981, 2450, 10));
		ksession.insert(new Emp(7566, "PUTIN", "MANAGER", 7839, 1981, 2975, 20));
		ksession.insert(new Emp(7654, "CHIRACK", "SALESMAN", 7698, 1981, 1250,30));
		ksession.insert(new Emp(7499, "BAROSSO", "SALESMAN", 7698, 1981, 1600,30));
		ksession.insert(new Emp(7844, "GATES", "SALESMAN", 7698, 1981, 1500, 30));
		ksession.insert(new Emp(7900, "BUFFETT", "CLERK", 7698, 1981, 950, 30));
		ksession.insert(new Emp(7521, "WALTON", "SALESMAN", 7698, 1981, 1250,30));
		ksession.insert(new Emp(7902, "TOOSK", "ANALYST", 7566, 1981, 3000, 20));
		ksession.insert(new Emp(7369, "THATCHER", "CLERK", 7902, 1980, 800, 20));
		ksession.insert(new Emp(7788, "CARNEGIE", "ANALYST", 7566, 1982, 3000,20));
		ksession.insert(new Emp(7876, "FORD", "CLERK", 7788, 1983, 1100, 20));
		//ksession.insert(new Emp(7934, "ELISON", "CLERK", 7782, 1982, 1300, 10));
		ksession.insert(new Emp(7698, "BLAIR", "MANAGER", 7839, 1981, 2850, 30));

		Emp elison = new Emp(7934, "ELISON", "CLERK", 7782, 1982, 1300, 10);
		FactHandle elisonFH = ksession.insert(elison);
		
		KnowledgeRuntimeLogger logger =
				KnowledgeRuntimeLoggerFactory.newFileLogger((KnowledgeRuntimeEventManager) ksession, "/tmp/logicalinsert_exercise");

		/**
		 * Write rules and test of a scenario, in which only employees working in department 10 are granted AccessToSecretFiles
		 * If they change their department or leave the company, the access should be revoked automatically
		 */
		ksession.fireAllRules();
		elison.setDeptno(20);
		ksession.update(elisonFH, elison);
		ksession.fireAllRules();
		//Use Audit view (/tmp/logicalinsert.log) to see whether Blair access to BusinessLounge has been removed
		
		logger.close();
	}
}
