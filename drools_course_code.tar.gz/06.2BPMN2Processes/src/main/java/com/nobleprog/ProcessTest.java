package com.nobleprog;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import com.nobleprog.Order;

public class ProcessTest {

	@Test
	public void Test01() {
		KieServices ks = KieServices.Factory.get();
		KieContainer kContainer = ks.getKieClasspathContainer();
		KieSession ksession = kContainer.newKieSession("ksession-rules");

//		ksession.insert(new Order("Course 1 (no discounts)", false, false, 900));
		// no discount should be applied

//		ksession.insert(new Order("Course 2 (tall order)", false, false, 1100));
		// tall order discount

		ksession.insert(new Order("Course 3 (existing customer)", false, true,
				10000));
		// existing customer

		ksession.startProcess("_45_DiscountProcess.discountProcess");
		ksession.fireAllRules();
	}
}
