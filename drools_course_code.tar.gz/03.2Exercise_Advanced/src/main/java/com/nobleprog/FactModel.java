package com.nobleprog;

import java.util.Date;

public class  FactModel{
	public static class Account {
		private long accountNo;
		public Account(long accountNo, double balance) {
			super();
			this.accountNo = accountNo;
			this.balance = balance;
		}
		private double balance;

		public long getAccountNo() {
			return accountNo;
		}
		public void setAccountNo(long accountNo) {
			this.accountNo = accountNo;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
	}
	
	public static class AccountPeriod {
		private Date start;
		private Date end;
		public Date getStart() {
			return start;
		}
		
		
		public AccountPeriod(Date start, Date end) {
			super();
			this.start = start;
			this.end = end;
		}


		public void setStart(Date start) {
			this.start = start;
		}
		public Date getEnd() {
			return end;
		}
		public void setEnd(Date end) {
			this.end = end;
		}
	}
	    
	
	public static class CashFlow{
		private Date date;
		public CashFlow(Date date, double amount, String type, long account) {
			super();
			this.date = date;
			this.amount = amount;
			this.type = type;
			this.account = account;
		}
		private double amount;
		private String type; //CREDIT or DEBIT
		private long account;
		public Date getDate() {
			return date;
		}
		public void setDate(Date date) {
			this.date = date;
		}
		public double getAmount() {
			return amount;
		}
		public void setAmount(double amount) {
			this.amount = amount;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public long getAccount() {
			return account;
		}
		public void setAccount(long account) {
			this.account = account;
		}
	}
}