package sample;


public class FactModel{

	public static class Emp {
		
		public Emp(long id, String name, String job, long mgr, int hiredate,
				long sal, int deptno) {
			super();
			this.id = id;
			this.name = name;
			this.job = job;
			this.mgr = mgr;
			this.hiredate = hiredate;
			this.sal = sal;
			this.deptno = deptno;
		}
		private long id;
		private String name;
		private String job;
		private long mgr;
		private int hiredate;
		private long sal;
		private int deptno;
		
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getJob() {
			return job;
		}
		public void setJob(String job) {
			this.job = job;
		}
		public long getMgr() {
			return mgr;
		}
		public void setMgr(long mgr) {
			this.mgr = mgr;
		}
		public int getHiredate() {
			return hiredate;
		}
		public void setHiredate(int hiredate) {
			this.hiredate = hiredate;
		}
		public long getSal() {
			return sal;
		}
		public void setSal(long sal) {
			this.sal = sal;
		}
		public int getDeptno() {
			return deptno;
		}
		public void setDeptno(int deptno) {
			this.deptno = deptno;
		}
	
	
	}
	
	public static class Dept {

		private int deptno;
		private String dname;
		private String loc;
		
		public Dept(int deptno, String dname, String loc) {
			this.deptno = deptno;
			this.dname = dname;
			this.loc = loc;
		}

		public int getDeptno() {
			return deptno;
		}
		public void setDeptno(int deptno) {
			this.deptno = deptno;
		}
		public String getDname() {
			return dname;
		}
		public void setDname(String dname) {
			this.dname = dname;
		}
		public String getLoc() {
			return loc;
		}
		public void setLoc(String loc) {
			this.loc = loc;
		}
		

		
	}
	
	public static class Salgrade {
	
		private int grade;
		private long losal;
		private long hisal;
		
		public Salgrade(int grade, long losal, long hisal) {
			super();
			this.grade = grade;
			this.losal = losal;
			this.hisal = hisal;
		}
		
		public int getGrade() {
			return grade;
		}
		public void setGrade(int grade) {
			this.grade = grade;
		}
		public long getLosal() {
			return losal;
		}
		public void setLosal(long losal) {
			this.losal = losal;
		}
		public long getHisal() {
			return hisal;
		}
		public void setHisal(long hisal) {
			this.hisal = hisal;
		}


	
	
	}
	
}