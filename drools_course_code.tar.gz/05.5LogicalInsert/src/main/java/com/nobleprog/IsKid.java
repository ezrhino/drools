package com.nobleprog;

public class IsKid {
	private Applicant applicant;

	public IsKid(Applicant a){
		this.applicant = a;
	}
	public Applicant getApplicant() {
		return applicant;
	}

	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}
}
