package com.nobleprog;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.StatelessKieSession;
import org.kie.api.runtime.rule.FactHandle;


public class Test01 {
	@Test
	public void test1(){
		
        KieServices ks = KieServices.Factory.get();
	    KieContainer kContainer = ks.getKieClasspathContainer();
    	KieSession kSession = kContainer.newKieSession("ksession-rules");
		

		Applicant applicant1 = new Applicant( "Bob", 20 );

		Applicant applicant2 = new Applicant( "BillKidd", 17 );


		kSession.insert(applicant1);
		FactHandle fh = kSession.insert(applicant2);
		kSession.fireAllRules( );

		
		
		applicant2.setAge(18);
		kSession.update(fh,applicant2);
		kSession.fireAllRules( );

	}
}
