package newpack;

public class FactModel {
	
	public static class Customer {
		
		@Override
		public String toString() {
			return "Customer [name=" + name + ", discount=" + discount + "]";
		}
		public Customer(String name, double discount) {
			super();
			this.name = name;
			this.discount = discount;
		}
		
		private String name;
		private double discount;
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public double getDiscount() {
			return discount;
		}
		public void setDiscount(double discount) {
			this.discount = discount;
		}
	}
	
	public static class Purchase {
		@Override
		public String toString() {
			return "Purchase [cust=" + cust + ", prod=" + prod + "]";
		}
		public Purchase(Customer cust, Product prod) {
			super();
			this.cust = cust;
			this.prod = prod;
		}
		private Customer cust;
		private Product prod;
		public Customer getCust() {
			return cust;
		}
		public void setCust(Customer cust) {
			this.cust = cust;
		}
		public Product getProd() {
			return prod;
		}
		public void setProd(Product prod) {
			this.prod = prod;
		}
	}
	
	public static class Discount {
		@Override
		public String toString() {
			return "Discount [cust=" + cust + ", discount=" + discount + "]";
		}
		public Discount(Customer cust, double discount) {
			super();
			this.cust = cust;
			this.discount = discount;
		}
		private Customer cust;
		private double discount;
		public Customer getCust() {
			return cust;
		}
		public void setCust(Customer cust) {
			this.cust = cust;
		}
		public double getDiscount() {
			return discount;
		}
		public void setDiscount(double discount) {
			this.discount = discount;
		}
	
	}
	
	public static class Product {
		public Product(String name, double price) {
			super();
			this.name = name;
			this.price = price;
		}
		@Override
		public String toString() {
			return "Product [name=" + name + ", price=" + price + "]";
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		private String name;
		private double price;
	}
}
