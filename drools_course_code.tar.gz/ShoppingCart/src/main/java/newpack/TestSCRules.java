package newpack;

import static org.junit.Assert.*;

import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import newpack.FactModel.*;
@SuppressWarnings("unused")
public class TestSCRules {

	@Test
	public void test() {
		KieServices ks = KieServices.Factory.get();
		KieContainer kContainer = ks.getKieClasspathContainer();
		KieSession ksession = kContainer.newKieSession("ksession-rules");

		/**
		 * Prepare Data
		 */
		Customer cust = new Customer("John", 0.0);
		ksession.insert(cust);
		
		Product prod1 = new Product("Foo", 600);
		ksession.insert(prod1);
		Product prod2 = new Product("Bar", 600);
		ksession.insert(prod2);
		Product prod3 = new Product("Baz", 600);
		ksession.insert(prod3);
		
		Purchase pur1 = new Purchase(cust, prod1);
		ksession.insert(pur1);
		Purchase pur2 = new Purchase(cust, prod2);
		ksession.insert(pur2);
		
		ksession.fireAllRules();
	}

}
